<?php if($authenticated): ?><?php $__env->startComponent('scribe::components.badges.base', ['colour' => "darkred", 'text' => 'requires authentication']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH F:\Programs\laragon\www\masbaapp\vendor\knuckleswtf\scribe\src/../resources/views//components/badges/auth.blade.php ENDPATH**/ ?>