<?php

namespace App\Filament\Resources\FranchiseResource\Pages;

use App\Filament\Resources\FranchiseResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateFranchise extends CreateRecord
{
    protected static string $resource = FranchiseResource::class;
}
