<?php

namespace App\Filament\Resources\LifeHacksCategoryResource\Pages;

use App\Filament\Resources\LifeHacksCategoryResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateLifeHacksCategory extends CreateRecord
{
    protected static string $resource = LifeHacksCategoryResource::class;
}
