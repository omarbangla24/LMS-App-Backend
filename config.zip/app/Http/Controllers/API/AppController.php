<?php

namespace App\Http\Controllers\API;

use Exception;
use App\Models\Slider;
use App\Models\Feature;
use App\Models\Workshop;
use App\Models\Franchise;
use Illuminate\Http\Request;
use App\Models\BusinessEvent;
use App\Http\Controllers\Controller;
use Symfony\Component\HttpKernel\Exception\HttpException;

class AppController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api', ['except' => ['slider']]);
    }

    public function slider(Request $request)
    {
 // Check if the user is authenticated
            if (auth('api')->check()) {
                // Get the sliders
                $sliders = Slider::all();

                // Return the sliders
                return response()->json([
                    'sliders' => $sliders,
                ]);
            }

    }

    public function features(Request $request)
    {

            // Check if the user is authenticated
            if (auth('api')->check()) {
                // Get the sliders
                $features = Feature::all();

                // Return the sliders
                return response()->json([
                    'sliders' => $features,
                ]);
            }
    }
    public function franchises(Request $request){
        if(auth('api')->check()){
            $franchises = Franchise::all();

            return response()->json([
                'franchise'=>$franchises,
            ]);
        }
    }
    public function workshops(Request $request){
        if(auth('api')->check()){
            $workshops = Workshop::all();
            return response()->json([
                'Workshops'=>$workshops,
            ]);
        }
    }
    public function businessevent(Request $request){
        if(auth('api')->check()){
            $BusinessEvents = BusinessEvent::all();
            return response()->json([
                'Business Events'=>$BusinessEvents,
            ]);
        }
    }
}
